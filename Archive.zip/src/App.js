import React, { useState } from 'react';
import './App.css';
import axios from 'axios';



function App() {

  const [showPokes, setShowPokes] = useState([]);


  const fetchPokes = () => {
    axios.get("https://pokeapi.co/api/v2/pokemon?limit=1118")
    .then(response=>{
    console.log(response.data);
    setShowPokes(response.data.results);
    })
  }

  return (
    <div className="App">
     <h1>Pokemon</h1>

<button onClick={fetchPokes}>Fetch Poke</button>
<hr />
      <ul>
        {showPokes.map((poke, i) => {
          return <li key = {i} >
            {poke.name}
          </li>
        })}
      </ul>
    </div>
  );
}

export default App;
